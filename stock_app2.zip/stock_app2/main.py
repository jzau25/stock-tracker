from flask import Flask, request, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///stocks.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)


# Define the User model
class StockUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    name = db.Column(db.String(120), unique=True, nullable=False)


class Stock(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), db.ForeignKey('stock_user.username'), nullable=False)
    ticker = db.Column(db.String(4), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)


with app.app_context():
    db.create_all()


@app.route('/', methods=['GET'])
def add_user():
    return render_template('create_account.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        username = request.form['username']
        name = request.form['name']
        user = StockUser.query.filter_by(username=username, name=name).first()
        if user:
            return redirect(url_for('home', username=username))
        else:
            return redirect(url_for('login'))
    else:
        return render_template('login.html')


@app.route('/create_account', methods=['POST'])
def user_submit():
    username = request.form['username']
    user = StockUser.query.filter_by(username=username).first()
    if user:
        return redirect(url_for('login'))
    else:
        name = request.form['name']
        new_user = StockUser(username=username, name=name)
        db.session.add(new_user)
        db.session.commit()
    return redirect(url_for('home', username=username))


@app.route('/home/<username>')
def home(username):
    user = StockUser.query.filter_by(username=username).first()
    if user:
        user_stocks = Stock.query.filter_by(username=username).all()
        return render_template('home.html', username=username, user_stocks=user_stocks)
    else:
        return redirect(url_for('add_user'))


@app.route('/add_stock_page/<username>')
def add_stock_page(username):
    user = StockUser.query.filter_by(username=username).first()
    if user:
        user_stocks = Stock.query.filter_by(username=username).all()
        return render_template('add_stock.html', username=username, stocks=user_stocks)
    else:
        return redirect(url_for('add_user'))


@app.route('/delete_stock_page/<username>')
def delete_stock_page(username):
    user = StockUser.query.filter_by(username=username).first()
    if user:
        user_stocks = Stock.query.filter_by(username=username).all()
        return render_template('delete_stock.html', username=username, stocks=user_stocks)
    else:
        return redirect(url_for('add_user'))


@app.route('/delete_account/<username>')
def delete_account(username):
    user = StockUser.query.filter_by(username=username).first()
    if user:
        Stock.query.filter_by(username=username).delete()
        db.session.delete(user)
        db.session.commit()
    return redirect(url_for("add_user"))


@app.route('/add_stock', methods=['POST'])
def add_stock():
    username = request.form['username']
    user = StockUser.query.filter_by(username=username).first_or_404()
    if user:
        ticker = request.form['ticker']
        quantity = request.form['quantity']
        new_stock = Stock(username=username, ticker=ticker, quantity=quantity)
        db.session.add(new_stock)
        db.session.commit()
        return redirect(url_for('add_stock_page', username=username))  # Redirect back to the home page
    else:
        return redirect(url_for('add_user'))


@app.route('/delete_stock', methods=['POST'])
def delete_stock():
    username = request.form['username']
    user = StockUser.query.filter_by(username=username).first_or_404()
    if user:
        ticker = request.form['ticker']
        quantity_to_delete = int(request.form['quantity'])
        stock = Stock.query.filter_by(username=username, ticker=ticker).first()
        if stock:
            if quantity_to_delete >= stock.quantity:
                db.session.delete(stock)
            else:
                stock.quantity -= quantity_to_delete
                db.session.add(stock)

            db.session.commit()
            return redirect(url_for('delete_stock_page', username=username))
        else:
            return redirect(url_for('delete_stock_page', username=username))


# Run the app
if __name__ == '__main__':
    app.run(debug=True)
